# -*- coding: UTF-8 -*-

from six import iteritems
import os.path
from .import de
from .import en

scraper_source = os.path.dirname(__file__)
__all__ = [x[1] for x in os.walk(os.path.dirname(__file__))][0]

##--en--##
english_providers = en.__all__
##--de--##
german_providers = de.__all__

##--All Providers--##
total_providers = {'en': english_providers, 'de': german_providers}
all_providers = []
for key, value in iteritems(total_providers):
	all_providers += value
