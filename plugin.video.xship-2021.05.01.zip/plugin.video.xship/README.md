![Xship logo](https://raw.githubusercontent.com/watchone/plugin.video.xship/master/resources/media/icon.png?token=ATYPDJZZEA2SBTVHJBAN5ETARBIIQ)


## Willkommen bei Xship für Kodi!

Bei Xship handelt es sich um ein Video-Addon für Kodi, welches das Streamen von Filmen und Serien über eine intuitive und optisch ansprechende Benutzeroberfläche ermöglicht

Der Schwerpunkt des Addons liegt darin, die Indexseiten lauffähig zu halten

Die Angebotenen Webseiten werden als Indexseiten bezeichnet, welche auf die eigentlichen Quellen verweisen die für das bereitgestellte Angebot verantworlich sind! 

[![Join the chat at https://gitter.im/Lastship_Chat/xStream](https://badges.gitter.im/Lastship_Chat/xStream.svg)](https://gitter.im/X-ship/community)
